package com.example.devi.financeapp;
// By: Devi Manivannan
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.StaticLabelsFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static android.graphics.Color.GREEN;

public class LineGraph extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int expenses[] = { 300, 510, 420, 250, 280};
        String dates[] = {"4/18","4/25", "5/2", "5/9","5/16"};
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_line_graph);

        GraphView graph = (GraphView) findViewById(R.id.graph);
        DataPoint[] points = new DataPoint[expenses.length];
        for (int i = 0; i < points.length; i++) {
            points[i] = new DataPoint(i, expenses[i]);
        }


        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(points);


        // use static labels for horizontal and vertical labels
        StaticLabelsFormatter staticLabelsFormatter = new StaticLabelsFormatter(graph);
        staticLabelsFormatter.setHorizontalLabels(dates);
       // staticLabelsFormatter.setVerticalLabels(new String[] {"low", "middle", "high"});
        graph.getGridLabelRenderer().setLabelFormatter(staticLabelsFormatter);
        graph.addSeries(series);

        series.setColor(0xFF0B7469);
        series.setDrawBackground(true);


    }

}
